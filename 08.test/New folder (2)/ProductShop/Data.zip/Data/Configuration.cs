﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-R3DB24I\SQLEXPRESS;Database=ProductShop2;Integrated Security=True;Encrypt=False";
    }
}
