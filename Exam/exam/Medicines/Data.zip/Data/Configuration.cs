﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-R3DB24I\SQLEXPRESS;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
